import java.io.FileNotFoundException;
import java.util.ArrayList;
import java.util.List;
import javafx.event.ActionEvent;
import javafx.event.EventHandler;
import javafx.geometry.Insets;
import javafx.scene.Scene;
import javafx.scene.control.Alert;
import javafx.scene.control.Alert.AlertType;
import javafx.scene.control.ChoiceBox;
import javafx.scene.control.Label;
import javafx.scene.control.TextField;
import javafx.scene.effect.DropShadow;
import javafx.scene.image.Image;
import javafx.scene.image.ImageView;
import javafx.scene.input.MouseEvent;
import javafx.scene.layout.AnchorPane;
import javafx.scene.layout.Background;
import javafx.scene.layout.BackgroundImage;
import javafx.scene.layout.BackgroundPosition;
import javafx.scene.layout.BackgroundRepeat;
import javafx.scene.layout.HBox;
import javafx.scene.layout.Pane;
import javafx.scene.paint.Color;
import javafx.scene.text.Font;
import javafx.scene.text.Text;
import javafx.stage.Stage;
import javafx.scene.control.ButtonType;

public class ViewManager {

	private static final int HEIGHT = 768;
	private static final int WIDTH = 1024;
	AnchorPane mainPane, helpPane,startPane;
	Stage stage;
	private Scene mainScene;
	private static Stage mainStage;
	static Stage gameStage = new Stage();
	
	private final static int MENU_BUTTONS_START_X = 100;
	private final static int MENU_BUTTONS_START_Y = 165;
	static int gameWidth;
	static int gameHeight;
	static int pointsM1, pointsM2;
	int y = 245;
	int lblY = 250;
	double playerY = 325;
	static String monkey1Color,monkey2Color;
	
	List<GorillaButton> menuButtons;
	TextField height, width, numberOfPoints;
	static ChoiceBox<String> color,color1,gravity;
	private final String FONT_PATH = "/kenvector_future.ttf";

	public Main game = new Main();
	public Game spillet;
	GorillaButton menuButton;

	public ViewManager() throws FileNotFoundException {
		menuButtons = new ArrayList<>();
		mainPane = new AnchorPane();
		mainScene = new Scene(mainPane,WIDTH,HEIGHT);
		mainStage = new Stage(); 
		mainStage.setScene(mainScene);
		createButtons();
		createBackground(mainPane);
		createLogo();
		
		mainStage.setOnCloseRequest(e -> {
            e.consume();
            logout(mainStage);

            });
	}
	
	private void createStartButton() throws FileNotFoundException {
		GorillaButton startButton = new GorillaButton ("PLAY");
		addMenuButton(startButton);
		
		startButton.setOnAction(new EventHandler<ActionEvent>(){
			
		@Override
		public void handle(ActionEvent arg0) {
			
				mainStage.close();

	            Stage settingStage = new Stage();
	            startPane = new AnchorPane();
	            Scene creditsScene = new Scene(startPane, WIDTH, HEIGHT);

	            Image backgroundImage = new Image ("background.jpg",256,256,false,true);
	    		BackgroundImage background = new BackgroundImage(backgroundImage, BackgroundRepeat.REPEAT,BackgroundRepeat.REPEAT,BackgroundPosition.DEFAULT,null);
	    		startPane.setBackground(new Background(background));
	            
	            Text guideOverskrift = new Text();
	            guideOverskrift.setText("Settings");
	            guideOverskrift.setFont(Font.font("Verdana", 40));
	            guideOverskrift.setFont(Font.loadFont(getClass().getResourceAsStream(FONT_PATH), 40));
	            guideOverskrift.setFill(Color.WHITE);
	            guideOverskrift.setX(WIDTH/2 - 110);
	            guideOverskrift.setY(HEIGHT/6);

	     
	            gravity = new ChoiceBox();
	            String[] levels = {"9.81 m/s^2 (Earth)","3.72 m/s^2 (Mars)","1.62 m/s^2 (Moon)"};
	            addChoiceBox(gravity,levels,"Select gravity","9.81 m/s^2 (Earth)");
	            	            
	            color = new ChoiceBox();
	            String[] colors = {"Black","Blue","Red"};
	            addChoiceBox(color,colors,"Select color","Blue");
	            
	            color1 = new ChoiceBox();	          
	            String[] colors1 = {"black","blue","red"};
	            addChoiceBox(color1,colors1,"Select color","Red");
	            
	   
	            createPlayerLabel("Player 1");
	            createPlayerLabel("Player 2");
	            createTextFields();
	            
	            GorillaButton bananaAnimation = new GorillaButton ("NO ANIM");
	            bananaAnimation.setLayoutX(640);
	            bananaAnimation.setLayoutY(625);

	            
	            bananaAnimation.setOnAction(g -> {
	            	if(!simulation.BananaBoolean) {
	            	bananaAnimation.setText("ANIM");
	            	simulation.BananaBoolean = true;
	            } else {
	            	bananaAnimation.setText("NO ANIM");
	            	simulation.BananaBoolean = false;
	            }
	           
	            });
	            startPane.getChildren().add(bananaAnimation);
	            
	            GorillaButton windButton = new GorillaButton ("WIND OFF");
	           

	            
	            windButton.setOnAction(g -> {
	            	if(!simulation.windBoolean) {
	            	windButton.setText("WIND ON");
	            	simulation.windBoolean = true;
	            } else {
	            	windButton.setText("WIND OFF");
	            	simulation.windBoolean = false;
	            }
	           
	            });
	            
	            settingStage.setOnCloseRequest(e -> {
                    e.consume();
                    logout(settingStage);

                    });
    			
    			GorillaButton play = new GorillaButton ("PLAY");
    			GorillaButton menuButton = new GorillaButton ("MENU");
    			
    			menuButton.setOnAction(j -> {
    	           settingStage.close();
    	        game.start(stage);
    	        });
	    		
    			startPane.getChildren().add(guideOverskrift);
    			
    			HBox in = new HBox();
	            in.setLayoutX(150);
	            in.setLayoutY(525);
	            in.setSpacing(40);
	            in.setPadding(new Insets(30, 40, 40, 30));
	            in.getChildren().addAll(menuButton,play,windButton);
	            startPane.getChildren().add(in);
	            
 	            settingStage.setScene(creditsScene);
 	            settingStage.show();
	    		
    			
    			
	    		 play.setOnAction(g -> {
	    			boolean pixelsOK = false;
	    			
					if(!(Utility.isInt(width.getText()))||!(Utility.isInt(height.getText()))) {
						guideOverskrift.setText("Please enter integers");
			            guideOverskrift.setX(WIDTH/2 - 300);
						}
					else if (Integer.parseInt(width.getText()) > 2000 || Integer.parseInt(height.getText()) > 1000) { 
						guideOverskrift.setText("Please lower your resolution");
						guideOverskrift.setX(WIDTH/2 - 421);
						} 
					else if (Integer.parseInt(width.getText()) <= 899 || Integer.parseInt(height.getText()) <= 699) {
						guideOverskrift.setText("Please increase your resolution");
						guideOverskrift.setX(WIDTH/2 - 450);
						} 
					else {
						pixelsOK = true;
						gameWidth = Integer.parseInt(width.getText());
						gameHeight =  Integer.parseInt(height.getText()); 
						}
			 
					if (pixelsOK) {
						int numberToWin = 0;
		 	            if(Utility.isInt(numberOfPoints.getText())) {
			            	numberToWin = Integer.parseInt(numberOfPoints.getText());
			            }
						
		    			spillet = new Game(gameWidth,gameHeight, numberToWin);
		    			settingStage.close();
		 				gameStage.setScene(spillet.Run());
		 				gameStage.setResizable(false);
		 				gameStage.show();
						}
	    			});
				}
			});
		}
	
	private void createHelpButton() {
		GorillaButton helpButton = new GorillaButton ("HELP");
		addMenuButton(helpButton);
			
		helpButton.setOnAction(g -> {
		mainStage.close();
		
		Stage helpStage = new Stage();
		helpPane = new AnchorPane();
		Scene helpScene = new Scene(helpPane, WIDTH, HEIGHT);
		Image backgroundImage = new Image ("background.jpg",256,256,false,true);
		BackgroundImage background = new BackgroundImage(backgroundImage, BackgroundRepeat.REPEAT,BackgroundRepeat.REPEAT,BackgroundPosition.DEFAULT,null);
		helpPane.setBackground(new Background(background));
		
				
		Text guideOverskrift = new Text();
		guideOverskrift.setText("Instructions");
		guideOverskrift.setFont(Font.loadFont(getClass().getResourceAsStream(FONT_PATH), 40));
		guideOverskrift.setFill(Color.WHITE);
		guideOverskrift.setX(WIDTH/2 - 150);
		guideOverskrift.setY(HEIGHT/6);
				
		Text guide = new Text();
        guide.setText(" The gorilla game is fun and easy to learn! "
                            + "\n You are playing as a monkey and your goal "
                            + "\n is to hit your opponents with your bananas before they hit you. "
                            + "\n In order to throw your banana you have to "
                            + "\n choose an angle and a speed for the throw."
                            + "\n In settings you can also choose to add wind "
                            + "\n or change the gravity to make the game more difficult."
                            + "\n "
                            + "\n Angle interval: 1 - 89 (integers)"
                            + "\n Speed interval: 1 - 200 (integers)"
                            + "\n Pixels height interval: 700 - 1000 (integers)"
                            + "\n Pixels width interval: 900 - 2000 (integers)"
                            );
		guide.setFont(Font.font ("Cambria", 30));
		guide.setFill(Color.WHITE);
		guide.setX(WIDTH/8);
		guide.setY(HEIGHT/4);
		
		
		helpStage.setOnCloseRequest(e -> {
			e.consume();
			logout(helpStage);
			
			});
		
		createMenuButton(helpStage,helpPane);
			
		helpPane.getChildren().addAll(guide,guideOverskrift);
		
		helpStage.setScene(helpScene);
		helpStage.show();
		});
	}
	
	private void createMonkeyPictures() {
        ImageView blue_monkey = new ImageView("/monkey_blue_display.png");
        ImageView red_monkey = new ImageView("/monkey_red_display.png");
        ImageView black_monkey = new ImageView("/monkey_black_display.png");
        int fitHeight = 110;
        int fitWidth = 110;
        blue_monkey.setLayoutX(375);
        blue_monkey.setLayoutY(90);
        
        blue_monkey.setFitHeight(fitHeight);
        blue_monkey.setFitWidth(fitWidth);
        
        red_monkey.setLayoutX(520);
        red_monkey.setLayoutY(190);
        
        red_monkey.setFitHeight(fitHeight);
        red_monkey.setFitWidth(130);
        
        black_monkey.setLayoutX(820);
        black_monkey.setLayoutY(338);
        
        black_monkey.setFitHeight(fitHeight);
        black_monkey.setFitWidth(fitWidth);
        
        mainPane.getChildren().addAll(blue_monkey,red_monkey,black_monkey);
    }

	private void createExitButton() throws FileNotFoundException {
		GorillaButton exitButton = new GorillaButton ("EXIT");
		addMenuButton(exitButton);
		
		exitButton.setOnAction(d -> {
        	logout(mainStage);
        });
	}
	
	private void createTextFields() {
	
		numberOfPoints = new TextField();
		addTextfields(numberOfPoints,350,440,50,450,"Points to win");
		
		numberOfPoints.setPromptText("3");
		
		width = new TextField();
		addTextfields(width,350,240,50,250, "Please select width");
		width.setPromptText("1300");

		height = new TextField();
		addTextfields(height,350,340,50,350,"Please select height");
		height.setPromptText("900");
	}
   	
	private void createBackground(Pane pane) {
		Image backgroundImage = new Image ("menu_background.png");
		BackgroundImage background = new BackgroundImage(backgroundImage, BackgroundRepeat.REPEAT,BackgroundRepeat.REPEAT,BackgroundPosition.DEFAULT,null);
		pane.setBackground(new Background(background));
	}
	
	private void createLogo() {
		ImageView logo = new ImageView("title.png");
		logo.setLayoutX(350);
		logo.setLayoutY(20);
		
		logo.setOnMouseEntered(new EventHandler<MouseEvent>() {

			@Override
			public void handle(MouseEvent event) {
				logo.setEffect(new DropShadow());
				
			}
		});
		
		logo.setOnMouseExited(new EventHandler<MouseEvent>() {

			@Override
			public void handle(MouseEvent event) {
				logo.setEffect(null);
				
			}
		});
		
		mainPane.getChildren().add(logo);
		
	}
	
	private void createPlayerLabel(String player) {
		Label player1 = new Label();
        player1.setText(player);
        player1.setLayoutX(780);
        player1.setLayoutY(playerY );
        player1.setMinWidth(75); 
        player1.setTextFill(Color.WHITE);
        player1.setFont(Font.loadFont(getClass().getResourceAsStream(FONT_PATH), 13));
        startPane.getChildren().add(player1);
        playerY+=100;
	}
	
	 private void createMenuButton(Stage mainStage, AnchorPane Pane) {
	        
	        GorillaButton menuButton = new GorillaButton ("MENU");

	        menuButton.setLayoutX(400);
	        menuButton.setLayoutY(600);
	        
	        Pane.getChildren().add(menuButton);
	                
	        menuButton.setOnAction(j -> {
	            mainStage.close();
	        game.start(stage);
	        });
	    }
	        
		

	
	private void createButtons() throws FileNotFoundException {
		createStartButton();	
		createHelpButton();
		createExitButton();
		createMonkeyPictures();
	}
	
	
	
		private void addMenuButton(GorillaButton button) {
			button.setLayoutX(MENU_BUTTONS_START_X);
			button.setLayoutY(MENU_BUTTONS_START_Y + menuButtons.size() * 75);
			
			menuButtons.add(button);
			mainPane.getChildren().add(button);
			 
		}
		private void addTextfields(TextField text, int textX, int textY,int lblX,int lblY, String type) {
			Label lblName = new Label(type); 
			lblName.setMinWidth(75); 
			lblName.setTextFill(Color.WHITE);
			lblName.setFont(Font.loadFont(getClass().getResourceAsStream(FONT_PATH), 18));
			lblName.setLayoutX(lblX);
			lblName.setLayoutY(lblY);	
			text.setPrefHeight(40);
			text.setPrefWidth(200);
	        text.setMaxWidth(100);
	        text.setLayoutX(textX);
			text.setLayoutY(textY);
			text.setStyle("-fx-font: 24 arial;");
			  
			startPane.getChildren().addAll(text,lblName);	
		}
		
		
		private void addChoiceBox(ChoiceBox<String> box, String[] levels, String string, String defaultChoice) {
			box.setValue(defaultChoice);
			box.getItems().addAll(levels);
			box.getSelectionModel();
			box.setLayoutX(780);
			box.setLayoutY(y);
			box.setPrefSize(200, 35);
			box.setOnAction(null);
	       
	        y += 100;
	       
	        Label Lbl = new Label();
	        Lbl.setText(string);
	        Lbl.setLayoutX(550);
	        Lbl.setLayoutY(lblY);
	        Lbl.setMinWidth(75); 
	        Lbl.setTextFill(Color.WHITE);
	        Lbl.setFont(Font.loadFont(getClass().getResourceAsStream(FONT_PATH), 18));
			
	        lblY += 100;
	        
	        startPane.getChildren().addAll(box,Lbl);
			
		}
		
		public static Stage getMainStage() {
			return mainStage;
		}
		
		public int getWidth() {
			return gameWidth;
		}
		public int getHeight() {
			return gameHeight;
		}

		public static void start() {
		mainStage.show();
			
		}
		public static void logout(Stage mainStage)  {
			Alert alert = new Alert(AlertType.CONFIRMATION);
			alert.setTitle("Exit");
			alert.setHeaderText("Are you sure you want to exit?");
			
			if(alert.showAndWait().get() == ButtonType.OK) {
				mainStage.close();
			}
		}
			
		public static void close() {
			gameStage.close();
			gameStage.setScene(null);
		}

		public static String getMonkeyColor1() {
			monkey1Color = color.getValue().toString();
			return "monkey_throw_"+monkey1Color.toLowerCase()+".png";
		}

		public static String getMonkeyColor2() {
			monkey2Color = color1.getValue().toString();
			return "monkey_throw_"+monkey2Color.toLowerCase()+"2.png";
		}

		
		
		
	  
	}

