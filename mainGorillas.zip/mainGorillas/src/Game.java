
import javafx.geometry.Insets;
import javafx.scene.Scene;
import javafx.scene.canvas.Canvas;
import javafx.scene.canvas.GraphicsContext;
import javafx.scene.control.Alert;
import javafx.scene.control.Alert.AlertType;
import javafx.scene.control.Button;
import javafx.scene.control.TextField;
import javafx.scene.image.Image;
import javafx.scene.image.ImageView;
import javafx.scene.image.PixelReader;
import javafx.scene.layout.AnchorPane;
import javafx.scene.layout.GridPane;
import javafx.scene.layout.HBox;
import javafx.scene.layout.VBox;
import javafx.scene.paint.Color;
import javafx.scene.shape.Polygon;
import javafx.scene.shape.Rectangle;
import javafx.scene.text.Font;
import javafx.stage.Stage;
import javafx.scene.control.ButtonType;


public class Game {
	static int pointsM1, pointsM2;
	int angleVal, velocityVal, pointsMonkey1, pointsMonkey2, gameWidth, gameHeight;
	int rounds = 1; 
	
	Scene mainScene;
	Stage primaryStage;
	
	simulation graph = new simulation();
	Main game = new Main();
	AnchorPane root = new AnchorPane();
	GraphicsContext context;
	animationThread animation;
	
	Image image2 = new Image ("/mainbackground.png");
	Image BACKGROUND_IMAGE = new Image("/deep_blue.png");
	
	Sprite monkey_win, monkey1, monkey2;
	
	GridPane gridPane1,gridPane2, gridPane3, gridPane4;
	ImageView healthbar1, healthbar2;
	VBox get_numbers;
	BonusModifier bonus;
	BMP bmp;
	ImageView hp_bar;
	
	boolean modifierExist;
	static int counter1 = 0;
	static int counter2 = 0;
	int numberToWin = 3;
	int windSel;
	
	Building[] buildings;
	double[] windConditions = new double[5];
	double[] aniWindConditions = new double[5];
	private Rectangle health1;
	private Rectangle health2;
	private VBox buttons;
	private static boolean monkey1Hit = false;
	private static boolean monkey2Hit = false;
	
	public final static int AMOUNT_OF_BUILDINGS = 10;
		
	
	public Game (int gameWidth, int gameHeight, int numberToWin) {
		
		if(!(numberToWin <= 0)) {
			this.numberToWin = numberToWin;
		}
		this.gameWidth = gameWidth;
		this.gameHeight = gameHeight;
		bmp = new BMP(gameWidth, gameHeight);
		
		Image image = new Image("/Windows.png");
		PixelReader reader = image.getPixelReader();
				
		buildings = new Building[AMOUNT_OF_BUILDINGS];
		int offset = 0;
		
		double defaultWidth = gameWidth / AMOUNT_OF_BUILDINGS;
		double[] buildingsWidth = new double[AMOUNT_OF_BUILDINGS];
		for(int i = 0; i < AMOUNT_OF_BUILDINGS; i++) {
			buildingsWidth[i] = defaultWidth;
		}
	
		for(int i = 0; i < AMOUNT_OF_BUILDINGS; i++) {
			
			int widthChange = Utility.getRandomInt(0, gameWidth / 25);
			buildingsWidth[i] += widthChange;
			double perBuildingChange = ((double)widthChange) / ((double)AMOUNT_OF_BUILDINGS - 1);
			for(int j = 0; j < AMOUNT_OF_BUILDINGS; j++) {
				if(i != j) {
					buildingsWidth[j] -= perBuildingChange; 
				}
			}
		}
		
		for(int i = 0; i < AMOUNT_OF_BUILDINGS - 1 ;i++) {
			int height = Utility.getRandomInt(gameHeight/5, (int)(gameHeight / 1.7));
			int width = (int)buildingsWidth[i];
			buildings[i] = new Building(width, height, offset, gameHeight, bmp, reader);
			offset += width;
		}
		
		int height = Utility.getRandomInt(gameHeight/5, (int)(gameHeight / 1.7));
		buildings[AMOUNT_OF_BUILDINGS - 1] = new Building(gameWidth - offset, height, offset, gameHeight, bmp, reader);		
		}
		
		
	public Scene Run() {
		//Start indstillinger
	    mainScene = new Scene(root, gameWidth, gameHeight);
		Canvas canvas = new Canvas(gameWidth, gameHeight);
		context = canvas.getGraphicsContext2D();
		ViewManager.gameStage.setTitle("Simp Gorillas");
		root.getChildren().add(canvas);
		
		//start betingelser
		addwindConditions();
		addAnimationWindConditions();
		createBackground();
		
		//start vind animation
		animation = new animationThread(gridPane1, gridPane2, gridPane3, gridPane4, gameWidth, gameHeight);
		animation.start();

		//elementer der skal inds�ttes
		//baggrund
		context.drawImage(image2,0,0, gameWidth, gameHeight);
		
		//monkey 1
		Building BM1 = buildings[1];
		monkey1 = new Sprite();
		monkey1.setImage(ViewManager.getMonkeyColor1());
		monkey1.position.set(
		BM1.offset + BM1.width / 2 - monkey1.getWidth() / 2, 
		gameHeight - BM1.height - monkey1.getHeight());
				
					
		//monkey 2
		Building BM2 = buildings[AMOUNT_OF_BUILDINGS - 2];
		monkey2 = new Sprite();
		monkey2.setImage(ViewManager.getMonkeyColor2());
		monkey2.position.set(
		BM2.offset + BM2.width / 2 - monkey2.getWidth() / 2, 
		gameHeight - BM2.height - monkey2.getHeight());
		
		// monkey win
		monkey_win = new Sprite();
		monkey_win.setImage("/monkey_win.png");
		
		//banekurve dot
		Sprite dot = new Sprite();
		dot.setImage("/dot.png");
		
		//spiller tur trekanter
		Polygon m1Triangle = drawTriangle(monkey1);
		Polygon m2Triangle = drawTriangle(monkey2);
        root.getChildren().add(m1Triangle);
		
		//vinkel og fart vindue
        TextField angle = new TextField();
        TextField speed = new TextField();
        angle.setPrefHeight(40);
        angle.setPrefWidth(200);
        angle.setMaxWidth(120);
        angle.setStyle("-fx-font: 24 arial;");
        angle.setFocusTraversable(false);
        speed.setPrefHeight(40);
        speed.setPrefWidth(200);
        speed.setMaxWidth(120);
        speed.setStyle("-fx-font: 24 arial;");
        speed.setFocusTraversable(false);
        
        angle.setPromptText("ANGLE");
        speed.setPromptText("SPEED");
        
        //tilbageknap
        GorillaButton back = new GorillaButton("Back");
        back.setScaleX(0.7);
        back.setScaleY(0.9);
        back.setLayoutX(gameWidth);
        back.setLayoutY(0);
        
		back.setOnAction(b -> {
		ViewManager.logout(ViewManager.gameStage);
		game.start(primaryStage);
		
		});
		
        //vind og tab spillet vindue
        GorillaButton next = new GorillaButton("New Game");
        GorillaButton logout = new GorillaButton("Exit");
        HBox in = new HBox();
        in.setLayoutX(gameWidth/3.8);
        in.setLayoutY(gameHeight/5);
        in.setSpacing(40);
        in.setPadding(new Insets(30, 40, 40, 30));
        in.getChildren().addAll(next,logout);
        
        // tegner healthbar
        health1 = addHealthbar(monkey1);
        health2 = addHealthbar(monkey2);
        
        
        
        windSel = Utility.getRandomInt(0,4);
        animation.setWind(aniWindConditions[windSel]); 
        graph.setWind(windConditions[windSel]);
        
        
        //button event
        GorillaButton button = new GorillaButton("Throw");
        button.setScaleX(0.7);
        button.setScaleY(0.9);
        button.setOnAction(e -> {     
        	
        	//f�r vinkel og hastighed fra tekstfelterne
            if(Utility.isInt(angle.getText())) {
                angleVal = Integer.parseInt(angle.getText());
            }
            if(Utility.isInt(speed.getText())) {
                velocityVal = Integer.parseInt(speed.getText());
            }
            
          
            
            //tjekker om vinkel og hastiged er over defineret v�rdier
            if(!(Utility.isInt(angle.getText()))) {
                wrongAngle();
            }

            if(!(Utility.isInt(speed.getText()))) {
                wrongSpeed();
            }
            
			if(Utility.isInt(angle.getText())) {

                if(Integer.parseInt(angle.getText()) > 89 || Integer.parseInt(angle.getText()) < 1) {
                    angleVal = Utility.getRandomInt(1, 89);
                    errorAngle();
                  }
                else {
                    angleVal = Integer.parseInt(angle.getText());
                }
            }
			
            if(Utility.isInt(speed.getText())) {
            	

            	
                if(Integer.parseInt(speed.getText()) > 200 || Integer.parseInt(speed.getText()) < 1) {
                    velocityVal = Utility.getRandomInt(1, 200);
                    errorSpeed();

                  }
                else {
                    velocityVal = Integer.parseInt(speed.getText());
                }

            }
            
            //wind

                    
            //clear baggrund
            context.drawImage(image2,0,0, gameWidth, gameHeight);
            
            //tilf�ldig multiplier
            if (Utility.getRandomInt(0,8) == 0){
        	    bonus = new BonusModifier(gameWidth, gameHeight);
        	    modifierExist = true;
           }
   			if (modifierExist ) {
   				bonus.render(context);
   				
   			}
    		//runder
			context.setFill(Color.YELLOW);
			context.setFont(new Font("Arial", 36));
					
			if (rounds%2 == 0) {
				removeTriangle(m2Triangle);
		        root.getChildren().add(m1Triangle);
				context.fillText("Runde: " + rounds, gameWidth/2 - 70, 35);
				rounds++;						
			}
			
			else {
				root.getChildren().remove(m1Triangle);
		        root.getChildren().add(m2Triangle);
				context.fillText("Runde: " + rounds, gameWidth/2 - 70, 35);
				rounds++;			    					
			}
			
			//tegner bygninger
			bmp.render(context);
			
			//tegner aber
            monkey1.render(context);
			monkey2.render(context);

			//point t�ller
			 if (rounds%2 == 0) {
	              graph.setup(angleVal, velocityVal, monkey1.position.x + 5, monkey1.position.y +5, root);
	               graph.draw(dot, monkey1, monkey2, rounds, bmp,context);
	   
			 }else {
	               graph.setup(180 - angleVal, velocityVal, monkey2.position.x + monkey2.boundary.width - 5, monkey2.position.y + 5, root );
	               graph.draw(dot, monkey1, monkey2, rounds,bmp,context);
	             
	           }
			 
			 //opdatere healthbars
			 updateHealthBars(health1, health2);

				
			
			if(pointsM1 >= numberToWin) {
				
				removeTriangle(m2Triangle);
				context.drawImage(image2,0,0, gameWidth, gameHeight);
				monkeyWin(monkey1);
	    		context.setFill(Color.YELLOW);
	    		context.setFont(new Font("Arial", 20));
		    	context.fillText("Congrats, monkey 1 wins!", gameWidth/2 - 150, 35);
		    	root.getChildren().remove(get_numbers);
		    	
		    	root.getChildren().removeAll(health1, health2, hp_bar);
		    	root.getChildren().add(in);
		    	
		        next.setOnAction(f -> {
		        	Sprite.count = 0;
		        	pointsM1 = 0;
		        	pointsM2 = 0;
		        	ViewManager.gameStage.close();
		        	game.start(primaryStage);
		        });
		    	
		        	logout.setOnAction(d -> {
		        		ViewManager.gameStage.close();
		        });
		    					    
			}
			if(pointsM2 >= numberToWin) {
				
                removeTriangle(m1Triangle);
                context.drawImage(image2,0,0, gameWidth, gameHeight);
                monkeyWin(monkey2);
                context.setFill(Color.YELLOW);
                context.setFont(new Font("Arial", gameWidth/17));
                context.fillText("Congrats, monkey 2 wins!", gameWidth/6, gameHeight/5);
                root.getChildren().removeAll(get_numbers,buttons);
                
                root.getChildren().removeAll(health1, health2, hp_bar);
                root.getChildren().add(in);
                
                next.setOnAction(f -> {
                	Sprite.count = 0;
                	pointsM1 = 0;
                    pointsM2 = 0;
                    ViewManager.gameStage.close();
                    game.start(primaryStage);
                });
                                        
                logout.setOnAction(d -> {
                    ViewManager.gameStage.close();
                });
		    	}
			
			
	        ViewManager.gameStage.setOnCloseRequest(q -> {
	            e.consume();
	            ViewManager.logout(ViewManager.gameStage);

	            });
			
			//point tekst
			context.setFill(Color.YELLOW);
			context.setFont(new Font("Arial", 36));
			context.fillText(""+pointsM1, 10, 175);
			context.fillText(""+pointsM2, gameWidth-37, 175);
			
			
           windSel = Utility.getRandomInt(0,4);
            animation.setWind(aniWindConditions[windSel]); 
            graph.setWind(windConditions[windSel]);
			
        });
        
        //tegner 
        //vinkel og fart box
        get_numbers = new VBox();
        get_numbers.setSpacing(7);
        get_numbers.setPadding(new Insets(20, 20, 20, 20));
        get_numbers.getChildren().addAll(angle, speed);
        root.getChildren().add(get_numbers);
        
        buttons = new VBox();
        buttons.setLayoutX(100);
        buttons.setLayoutY(-3);
        buttons.setSpacing(2);
        buttons.setPadding(new Insets(20, 20, 20, 20));
        buttons.getChildren().addAll(button,back);
        root.getChildren().add(buttons);
        
        
        //tegner pointscore
        context.setFill(Color.YELLOW);
        context.setFont(new Font("Arial", 60));
        context.fillText("0", 5, 170);
        context.fillText("0", gameWidth-37, 175);
		
		//tegner aber
        monkey1.render(context);
		monkey2.render(context);

		//tegner bygninger
		bmp.render(context);
		return mainScene;
		
	}
	
	public Polygon drawTriangle(Sprite object) {
		Polygon polygonTri = new Polygon();
		polygonTri.setFill(Color.YELLOW);
		double trueY = object.position.y - 25;
		
		if (object.id == 1) {
			polygonTri.getPoints().addAll(new Double[]{
				object.position.x + 45, trueY - 25,
                object.position.x + object.boundary.width - 25, trueY - 25,
                object.position.x + 10 + object.boundary.width * 0.5, trueY - 10});
		}
		else {
			polygonTri.getPoints().addAll(new Double[]{
					object.position.x + 25, trueY - 25,
	                object.position.x + object.boundary.width - 45, trueY - 25,
	                object.position.x - 10 + object.boundary.width * 0.5, trueY - 10});
		}
		
		return polygonTri;
	}
	
	public Rectangle addHealthbar(Sprite monkey) {
		hp_bar = new ImageView("/healthbar_0.png"); 
		Rectangle health = new Rectangle();
		health.setWidth(82);
		health.setHeight(21);
		health.setFill(Color.LIGHTGREEN);
		
		if(monkey.id == 1) {
			hp_bar.setLayoutX(monkey.position.x + 5);
			hp_bar.setLayoutY(monkey.position.y - 30);
			
			health.setX(monkey.position.x + 5);
			health.setY(monkey.position.y - 29);


			
			
		} else {
			hp_bar.setLayoutX(monkey.position.x);
			hp_bar.setLayoutY(monkey.position.y - 30);
			health.setX(monkey.position.x);
			health.setY(monkey.position.y - 29);

		}
		
		root.getChildren().addAll(hp_bar, health);

		return health;
	}
	

	
	public void updateHealthBars(Rectangle bar1, Rectangle bar2) {
		
		
		if(monkey2Hit) {
			double newLength1 = bar1.getWidth() - bar1.getWidth() * (1.0 / (double)numberToWin);
			monkey2Hit  = false;
			bar1.setWidth(newLength1);

		}
		if(monkey1Hit) {
			double newLength2 = bar2.getWidth() - bar2.getWidth() * (1.0 / (double)numberToWin);
			monkey1Hit = false;
			bar2.setWidth(newLength2);

		}
		
		
		
		
		
	}
	
	public void removeTriangle(Polygon triangle) {
		root.getChildren().remove(triangle);
	}

	public static void inc_m1() {
		pointsM1++;
		monkey1Hit = true;

    }
  
    public static void inc_m2() {
    	pointsM2++;
    	monkey2Hit = true;

}
    private void createBackground() {
		gridPane1 = new GridPane();
		gridPane2 = new GridPane();
		gridPane3 = new GridPane();
		gridPane4 = new GridPane();
		double newWidth = gameWidth/5;
		double newHeight = gameHeight/3;
		
		for (int row = 0 ; row < 3; row++) {
			for(int colum = 0; colum < 5; colum++) {
			ImageView backgroundImage1 = new ImageView(BACKGROUND_IMAGE);
			ImageView backgroundImage2 = new ImageView(BACKGROUND_IMAGE);
			ImageView backgroundImage3 = new ImageView(BACKGROUND_IMAGE);
			ImageView backgroundImage4 = new ImageView(BACKGROUND_IMAGE);
			backgroundImage1.setFitWidth(newWidth);
			backgroundImage1.setFitHeight(newHeight);
			backgroundImage2.setFitWidth(newWidth);
			backgroundImage2.setFitHeight(newHeight);
			backgroundImage3.setFitWidth(newWidth);
			backgroundImage3.setFitHeight(newHeight);
			backgroundImage4.setFitWidth(newWidth);
			backgroundImage4.setFitHeight(newHeight);
			
			GridPane.setConstraints(backgroundImage1, colum, row );
			GridPane.setConstraints(backgroundImage2, colum, row );
			GridPane.setConstraints(backgroundImage3, colum, row );
			GridPane.setConstraints(backgroundImage4, colum, row );
			gridPane1.getChildren().add(backgroundImage1);
			gridPane2.getChildren().add(backgroundImage2);
			gridPane3.getChildren().add(backgroundImage3);
			gridPane4.getChildren().add(backgroundImage4);
			}
		}
		
		gridPane1.setLayoutX(-(gameWidth*0.5));
		gridPane1.setLayoutY(-(gameHeight*0.5));
		gridPane2.setLayoutX(gameWidth*0.5);
		gridPane2.setLayoutY(-(gameHeight*0.5));
		gridPane3.setLayoutX(-(gameWidth*0.5));
		gridPane3.setLayoutY(gameHeight*0.5);
		gridPane4.setLayoutX(gameWidth*0.5);
		gridPane4.setLayoutY(gameHeight*0.5);
		root.getChildren().addAll(gridPane1, gridPane2, gridPane3, gridPane4);
	}
    public void addAnimationWindConditions() {
    	aniWindConditions[0] = -2;
    	aniWindConditions[1] = -0.5;
    	aniWindConditions[2] = 0;
    	aniWindConditions[3] = 0.5;
    	aniWindConditions[4] = 2;
    }
    
    public void addwindConditions() {
		windConditions[0] = -0.01;
		windConditions[1] = -0.007;
		windConditions[2] = 0;
		windConditions[3] = 0.007;
		windConditions[4] = 0.01;
		
	}
    public void monkeyWin (Sprite monkey) {
        if(monkey.id == 1) {
            ImageView winImage = new ImageView("/monkey_win_" + ViewManager.monkey1Color.toLowerCase() + ".png");
            winImage.setFitWidth(150);
            winImage.setFitHeight(178);
            winImage.setLayoutX(gameWidth*0.25 - winImage.getFitWidth());
            winImage.setLayoutY(gameWidth*0.4);
            root.getChildren().add(winImage);
        }
        else {
            ImageView winImage = new ImageView("/monkey_win_" + ViewManager.monkey2Color.toLowerCase() + ".png");
            winImage.setLayoutX(gameWidth*0.75);
            winImage.setLayoutY(gameWidth*0.4);
            winImage.setFitWidth(150);
            winImage.setFitHeight(178);
            root.getChildren().add(winImage);
        }

    }
    public static int roundUp(double num, int divisor) {
        return (int) ((num + divisor - 1) / divisor);
    }
   
    private void errorAngle()  {
        Alert error = new Alert(AlertType.ERROR);
        error.setTitle("Angle is out of the correct field");
        error.setHeaderText("You have received a random angle for your throw");
        error.setContentText("Next time choose an angle between 1 and 89");

        if(error.showAndWait().get() == ButtonType.OK) {
            error.close();
        }
}

    private void errorSpeed() {
    Alert error = new Alert(AlertType.ERROR);
    error.setTitle("Speed is out of the correct field");
    error.setHeaderText("You have received a random speed for your throw");
    error.setContentText("Next time choose a speed between 1 and 200");

    if(error.showAndWait().get() == ButtonType.OK) {
        error.close();
    }

}
    private void wrongAngle() {
        Alert error = new Alert(AlertType.ERROR);
        error.setTitle("You can only enter numbers");
        error.setHeaderText("You have received a random angle for your throw");
        error.setContentText("Next time choose an angle between 1 and 89 in numbers");


        if(error.showAndWait().get() == ButtonType.OK) {
                error.close();
        }



    }


    private void wrongSpeed() {
        Alert error = new Alert(AlertType.ERROR);
        error.setTitle("You can only enter numbers");
        error.setHeaderText("You have received a random speed for your throw");
        error.setContentText("Next time choose a speed between 1 and 200 in numbers");


        if(error.showAndWait().get() == ButtonType.OK) {
                error.close();
        }
    
    }
}