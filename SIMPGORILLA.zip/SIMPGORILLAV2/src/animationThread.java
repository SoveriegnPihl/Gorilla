import javafx.animation.AnimationTimer;
import javafx.scene.layout.GridPane;

public class animationThread extends Thread{
	GridPane gridPane1, gridPane2, gridPane3, gridPane4;
	double windSpeed = 0;
	double gameWidth, gameHeight;
	
	public animationThread(GridPane g1, GridPane g2, GridPane g3, GridPane g4, double width, double height) {
		this.gridPane1 = g1;
		this.gridPane2 = g2;
		this.gridPane3 = g3;
		this.gridPane4 = g4;
		gameWidth = width;
		gameHeight = height;
	}
	
	public void setWind(double windSpeed) {
		if(!simulation.windBoolean) {
			this.windSpeed = 0;
		} else {
			this.windSpeed = windSpeed;
		}
	}
	@Override
	public void run() {
		AnimationTimer gameTimer = new AnimationTimer() {
			@Override
			public void handle(long now) {	
			
				gridPane1.setLayoutY(gridPane1.getLayoutY() + 0.5);
				gridPane2.setLayoutY(gridPane2.getLayoutY() + 0.5);
				gridPane3.setLayoutY(gridPane3.getLayoutY() + 0.5);
				gridPane4.setLayoutY(gridPane4.getLayoutY() + 0.5);
				gridPane1.setLayoutX(gridPane1.getLayoutX() + windSpeed);
				gridPane2.setLayoutX(gridPane2.getLayoutX() + windSpeed);
				gridPane3.setLayoutX(gridPane3.getLayoutX() + windSpeed);
				gridPane4.setLayoutX(gridPane4.getLayoutX() + windSpeed);
				
				if(gridPane1.getLayoutY() >= gameHeight && gridPane2.getLayoutY() >= gameHeight) {
					gridPane1.setLayoutY(-gameHeight);
					gridPane2.setLayoutY(-gameHeight);
				}
				
				if(gridPane3.getLayoutY() >= gameHeight && gridPane4.getLayoutY() >= gameHeight) {
					gridPane3.setLayoutY(-gameHeight);
					gridPane4.setLayoutY(-gameHeight);
				}
				
				else if(gridPane1.getLayoutX() == 0 && gridPane3.getLayoutX() == 0) {
					gridPane2.setLayoutX(-gameWidth);
					gridPane4.setLayoutX(-gameWidth);
				}
				
				else if(gridPane2.getLayoutX() == 0 && gridPane4.getLayoutX() == 0) {
					gridPane1.setLayoutX(gameWidth);
					gridPane3.setLayoutX(gameWidth);
				}
				
				else if(gridPane1.getLayoutX() >= gameWidth && gridPane3.getLayoutX() >= gameWidth) {
					gridPane1.setLayoutX(-gameWidth);
					gridPane3.setLayoutX(-gameWidth);
				}
				
				else if(gridPane2.getLayoutX() >= gameWidth && gridPane4.getLayoutX() >= gameWidth) {
					gridPane2.setLayoutX(-gameWidth);
					gridPane4.setLayoutX(-gameWidth);
				}
				
				else if(gridPane1.getLayoutX()+gameWidth <= 0 && gridPane3.getLayoutX()+gameWidth <= 0) {
					gridPane1.setLayoutX(gameWidth);
					gridPane3.setLayoutX(gameWidth);
				}
				
				else if(gridPane2.getLayoutX()+gameWidth <= 0 && gridPane4.getLayoutX()+gameWidth  <= 0) {
					gridPane2.setLayoutX(gameWidth);
					gridPane4.setLayoutX(gameWidth);
				}
			}
		};
		gameTimer.start();
	}

}
