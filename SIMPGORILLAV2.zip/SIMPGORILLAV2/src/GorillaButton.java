import javafx.event.EventHandler;
import javafx.scene.control.Button;
import javafx.scene.effect.DropShadow;
import javafx.scene.input.MouseButton;
import javafx.scene.input.MouseEvent;
import javafx.scene.text.Font;

public class GorillaButton extends Button{
	
	String fontStyle = "kenvector_future.ttf";
	String pressedButton = "-fx-background-color: transparent; -fx-background-image: url('blue_button05.png')";
	String freeButton = "-fx-background-color: transparent; -fx-background-image: url('blue_button04.png')";
	
	public GorillaButton(String text) {
		setText(text);
		fontButton();
		setPrefWidth(190);
		setPrefHeight(49);
		setStyle(freeButton);
		buttonListeners();
	}

	private void fontButton() {
		setFont(Font.loadFont(getClass().getResourceAsStream(fontStyle), 23));
	}
	
	private void pressedButton() {
		setStyle(pressedButton);
		setPrefHeight(45);
		setLayoutY(getLayoutY() + 4);
	}
	
	private void releasedButton() {
		setStyle(freeButton);
		setPrefHeight(45);
		setLayoutY(getLayoutY() - 4);
	}
	
	private void buttonListeners() {
		setOnMousePressed(new EventHandler<MouseEvent>() {

			@Override
			public void handle(MouseEvent event) {
				if(event.getButton().equals(MouseButton.PRIMARY)) {
						pressedButton();
				}
			}
		});
		
		setOnMouseReleased(new EventHandler<MouseEvent>() {

			@Override
			public void handle(MouseEvent event) {
				if(event.getButton().equals(MouseButton.PRIMARY)) {
					releasedButton();
				}
			}
		});
		
		setOnMouseEntered(new EventHandler<MouseEvent>() {

			@Override
			public void handle(MouseEvent event) {
				setEffect(new DropShadow());
			}
		});
		
		setOnMouseExited(new EventHandler<MouseEvent>() {

			@Override
			public void handle(MouseEvent event) {
				setEffect(null);	
			}
		});
		
	}
	
}